(function () {
  "use strict";
  var L = {}; // layered data

  var $ = function (id) { return document.getElementById(id); };
  var el = {
    content: $("content"),
    playlistsView: $("playlistsView"),
    tracksView: $("tracksView"),
    grid: $("playlistsGrid"),
    trackList: $("trackList"),
    trackListTitle: $("trackListTitle"),
    btnPlaylists: $("btnPlaylists"),
    btnLibrary: $("btnLibrary"),
    player: $("player"),
    nowTitle: $("nowTitle"),
    nowSub: $("nowSub"),
    audio: $("audio"),
    playBtn: $("playBtn"),
    btnPrev: $("btnPrev"),
    btnNext: $("btnNext"),
    btnShuffle: $("btnShuffle"),
    btnRepeat: $("btnRepeat"),
    seek: $("seek"),
    curTime: $("curTime"),
    totTime: $("totTime")
  };

  var state = {
    queue: [],          // array of track objects currently loaded (playlist view)
    indexAt: -1,        // position within the playing order (see order())
    shuffled: false,
    order: [],          // array of indices into state.queue (identity if not shuffled)
    repeat: "off"       // off | all | one
  };

  // The currently-playable order, as indices into state.queue.
  function order() {
    return state.shuffled ? state.order : state.queue.map(function (_, i) { return i; });
  }

  function current() {
    var o = order();
    if (state.indexAt < 0 || state.indexAt >= o.length) return null;
    return state.queue[o[state.indexAt]];
  }

  // Position in the *visible* track list of the currently playing track.
  function currentVisibleIndex() {
    var t = current();
    if (!t) return -1;
    for (var i = 0; i < state.queue.length; i++) {
      if (state.queue[i] === t) return i;
    }
    return -1;
  }

  function fmt(t) {
    if (!isFinite(t) || t < 0) t = 0;
    var m = Math.floor(t / 60), s = Math.floor(t % 60);
    return m + ":" + (s < 10 ? "0" : "") + s;
  }

  function loadData(cb) {
    fetch("playlists.json")
      .then(function (r) { return r.json(); })
      .then(function (d) {
        L.playlists = d.playlists || [];
        var all = [];
        L.playlists.forEach(function (p) {
          (p.tracks || []).forEach(function (t) {
            var c = {};
            for (var k in t) c[k] = t[k];
            c.playlist = p.name;
            all.push(c);
          });
        });
        L.all = all;
        cb();
      })
      .catch(function () {
        el.grid.innerHTML = '<div class="empty">Could not load playlists.json.<br>Make sure the audio and data files are alongside this page.</div>';
      });
  }

  function renderPlaylists() {
    el.grid.innerHTML = "";
    if (!L.playlists.length) {
      el.grid.innerHTML = '<div class="empty">No playlists found in this export.</div>';
      return;
    }
    L.playlists.forEach(function (p) {
      var div = document.createElement("div");
      div.className = "pl";
      div.innerHTML =
        '<img src="' + (p.cover || "art/blank.jpg") + '" alt="">' +
        '<div class="plname">' + esc(p.name) + '</div>' +
        '<div class="plcount">' + (p.tracks ? p.tracks.length : 0) + ' tracks</div>';
      div.addEventListener("click", function () { openPlaylist(p.name); });
      el.grid.appendChild(div);
    });
  }

  function renderTracks(list, title) {
    el.trackListTitle.textContent = title;
    el.trackList.innerHTML = "";
    list.forEach(function (t, i) {
      var div = document.createElement("div");
      div.className = "track";
      div.innerHTML =
        '<span class="eq">&#9836;</span>' +
        '<img src="' + (t.art || "art/blank.jpg") + '" alt="">' +
        '<div class="meta"><div class="title">' + esc(t.title) + '</div>' +
        '<div class="sub">' + esc(t.artist || "") + (t.album ? " &middot; " + esc(t.album) : "") + '</div></div>' +
        '<span class="dur">' + (t.duration ? fmt(t.duration) : "") + '</span>';
      div.addEventListener("click", function () {
        setQueue(list, i);
        play();
      });
      el.trackList.appendChild(div);
    });
    // mark playing row
    highlightPlaying();
  }

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function showView(name) {
    if (name === "playlists") {
      el.playlistsView.classList.remove("hide");
      el.tracksView.classList.add("hide");
      el.btnPlaylists.classList.add("active");
      el.btnLibrary.classList.remove("active");
      renderPlaylists();
    } else {
      el.playlistsView.classList.add("hide");
      el.tracksView.classList.remove("hide");
      el.btnLibrary.classList.add("active");
      el.btnPlaylists.classList.remove("active");
      renderTracks(L.all, "All Tracks");
    }
  }

  function openPlaylist(name) {
    L.playlists.forEach(function (p) {
      if (p.name === name) {
        el.playlistsView.classList.add("hide");
        el.tracksView.classList.remove("hide");
        el.btnPlaylists.classList.remove("active");
        el.btnLibrary.classList.remove("active");
        renderTracks(p.tracks || [], name);
      }
    });
  }

  function setQueue(list, startIdx) {
    state.queue = list;
    state.order = state.queue.map(function (_, i) { return i; });
    state.indexAt = startIdx;
    highlightPlaying();
  }

  function play() {
    var t = current();
    if (!t) return;
    el.nowTitle.textContent = t.title;
    el.nowSub.textContent = (t.artist || "") + (t.album ? " &middot; " + t.album : "");
    el.audio.src = t.file;
    el.player.classList.remove("hide");
    el.audio.play();
    updatePlayBtn();
    highlightPlaying();
  }

  function next(manual) {
    var o = order();
    var n = o.length;
    if (!n) return;
    if (state.repeat === "one" && !manual) {
      el.audio.currentTime = 0;
      el.audio.play();
      return;
    }
    var i = state.indexAt + 1;
    if (i >= n) {
      if (state.repeat === "all") {
        i = 0;
      } else {
        el.audio.pause();
        el.audio.currentTime = 0;
        state.indexAt = 0;
        updatePlayBtn();
        highlightPlaying();
        return;
      }
    }
    state.indexAt = i;
    play();
  }

  function prev() {
    var n = order().length;
    if (!n) return;
    if (el.audio.currentTime > 3) {
      el.audio.currentTime = 0;
      return;
    }
    var i = state.indexAt - 1;
    if (i < 0) i = n - 1;
    state.indexAt = i;
    play();
  }

  function togglePlay() {
    if (!current()) return;
    if (el.audio.paused) el.audio.play(); else el.audio.pause();
  }

  function updatePlayBtn() {
    if (el.audio.paused) el.playBtn.innerHTML = "&#9654;"; else el.playBtn.innerHTML = "&#10074;&#10074;";
  }

  function highlightPlaying() {
    var rows = el.trackList.querySelectorAll(".track");
    var i = currentVisibleIndex();
    rows.forEach(function (row) { row.classList.remove("playing"); });
    if (i >= 0 && rows[i]) rows[i].classList.add("playing");
  }

  function shuffleOn() {
    state.shuffled = true;
    var idx = [];
    for (var i = 0; i < state.queue.length; i++) idx.push(i);
    for (var a = idx.length - 1; a > 0; a--) {
      var b = Math.floor(Math.random() * (a + 1));
      var t = idx[a]; idx[a] = idx[b]; idx[b] = t;
    }
    // ensure current track stays first in the new order
    var ci = currentVisibleIndex();
    state.order = idx;
    if (ci >= 0) {
      var pos = state.order.indexOf(ci);
      state.order.splice(pos, 1);
      state.order.unshift(ci);
    }
    state.indexAt = 0;
    el.btnShuffle.classList.add("on");
  }

  function shuffleOff() {
    state.shuffled = false;
    state.indexAt = currentVisibleIndex();
    el.btnShuffle.classList.remove("on");
  }

  function toggleShuffle() {
    if (state.shuffled) shuffleOff(); else shuffleOn();
  }

  function toggleRepeat() {
    if (state.repeat === "off") state.repeat = "all";
    else if (state.repeat === "all") state.repeat = "one";
    else state.repeat = "off";
    el.btnRepeat.classList.toggle("on", state.repeat !== "off");
    el.btnRepeat.textContent = state.repeat === "one" ? "1" : "&#8635;";
  }

  // ---- wiring ----
  el.btnPlaylists.addEventListener("click", function () { showView("playlists"); });
  el.btnLibrary.addEventListener("click", function () { showView("library"); });
  el.playBtn.addEventListener("click", togglePlay);
  el.btnPrev.addEventListener("click", prev);
  el.btnNext.addEventListener("click", function (e) { if (e.detail) next(true); else next(false); });
  el.btnShuffle.addEventListener("click", toggleShuffle);
  el.btnRepeat.addEventListener("click", toggleRepeat);

  el.audio.addEventListener("play", updatePlayBtn);
  el.audio.addEventListener("pause", updatePlayBtn);
  el.audio.addEventListener("ended", function () { next(false); });
  el.audio.addEventListener("loadedmetadata", function () {
    el.seek.max = Math.floor(el.audio.duration || 0);
    el.totTime.textContent = fmt(el.audio.duration);
    updateSeek();
  });
  el.seek.addEventListener("input", function () {
    el.audio.currentTime = parseInt(el.seek.value, 10);
  });

  var lastSeek = 0;
  function updateSeek() {
    var cur = el.audio.currentTime || 0;
    el.seek.value = Math.floor(cur);
    el.seek.max = Math.floor(el.audio.duration || 0);
    el.curTime.textContent = fmt(cur);
    el.totTime.textContent = fmt(el.audio.duration);
  }
  el.audio.addEventListener("timeupdate", function () {
    var now = Date.now();
    if (now - lastSeek > 250) { lastSeek = now; updateSeek(); }
  });

  loadData(function () {
    showView("playlists");
  });
})();
